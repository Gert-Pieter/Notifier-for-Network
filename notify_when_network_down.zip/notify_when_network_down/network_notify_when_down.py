#import time for time in between
#import request for ip checking 
#import request for notification

import time 
import requests
from plyer import notification

def home_ip():
    try:
        requests.get("https://google.com", timeout=5)
        return True
    except requests.RequestException:
        return False

was_connected = True

while True:
    connected = home_ip()
    print("Testing")
    # Notify when internet is off
    if not connected and was_connected:
        notification.notify(title="Internet Down", message="Your connection has been lost!", timeout=5)
    
    # Notify when internet comes back
    elif connected and not was_connected:
        notification.notify(title="Internet Back", message="Your connection is restored!", timeout=5)

    was_connected = connected
    time.sleep(10)
